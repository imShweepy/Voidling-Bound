# Voidling Bound Evolution Viewer

This is a standalone static website. It requires no server-side code, database, API, or external JavaScript libraries.

## Publish it
Upload the contents of this folder to any static web host. The entry point is `index.html`.

Recommended easy options:
- GitHub Pages
- Netlify
- Cloudflare Pages

Once published, open the site's URL in Safari on iPhone and share that URL.

## Controls
- The native SELECT VOIDLING dropdown switches the entire viewer.
- Quick buttons switch Voidlings.
- Search supports fuzzy matching, including misspellings such as `Kerapn` -> `Kerapin`.
- Evolution tier buttons filter the current Voidling.
